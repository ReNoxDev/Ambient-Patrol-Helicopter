A CALL FROM HOME — NAVEZGANE HOME GUARD
Version 0.1.1 — completion and APH isolation update

INSTALL
Extract ACallToHome into Mods. Install on the server and every client, with EAC disabled.
Ambient Patrol Helicopter is required; keep its folder named AmbientPatrolHelicopter,
including Resources/manux_HelicopterOH58.unity3d and its PatrolAudio folder.
Use an APH release compatible with your game version. This package does not replace APH.
CustomQuest is optional. If installed, use the separately supplied compatibility update.

PLAY
Find a Home Guard Favor Signal in an airdrop. Picking it up adds A Call From Home
as a native journal quest, without CustomQuest. Signals cannot be crafted, sold,
scrapped or stacked. Left-click to pull the cap and strike; allow three seconds.
Left-click again or right-click to throw. The flare follows a gravity arc and
settles on the ground. Its green smoke stops ten seconds after landing.
Home Guard flies in using the installed APH helicopter model, follows and circles
your position, and fires on zombies. Its 2400-second (40 real minute) duty period
starts on arrival. Only your defender is friendly; ordinary APH patrols retain
APH behavior. The defender currently cannot be damaged or looted.
The message is: You've called in a favor—let's hope it pans out!

RARITY AND LIMITS
Default chance: 1.5% per airdrop loot generation. Modded supply-crate entities
register their actual loot-container name; common airdrop container names also match.
Optional CustomQuest reward: 2.5% bonus chance after successful completion on Radio Relay, Live Specimen and
Airdrop quests, tiers 1–6. No changes to quest reward lists. Each completion records its bonus roll in native quest
variables, including failed rolls, to prevent another roll after save/load.
Quest reward execution follows the native local-owner reward path. Keep
QuestRewards, QuestRewardChance and LimitCarriedSignals consistent on clients
and server; the existing network protocol does not synchronize these settings.
Loot and reward grants skip players already carrying a signal when
LimitCarriedSignals=true. This discourages hoarding; it does not cap chest storage
or stop players trading signals. Server enforcement permits one active defender
per player and at least two in-game days between successful throws.
Cooldowns are keyed to the player's platform identity and saved in the world save
under A_Call_To_Home/Cooldowns.bin. A restart ends the current defender but retains
the cooldown. Death/disconnect retires support after 30 seconds by default.

SETTINGS
Settings.txt reloads every second. Edit on the server for gameplay, and on the
client for local grip and ignition presentation. Keep ignition settings consistent.
TargetScanSeconds controls how often zombies are selected; lower is faster.
ShotInterval, Damage, Accuracy, AttackRange, DefenseRadius, LineOfSight and
TargetOtherEnemies control attacks. Players and traders are always excluded.
FlightHeight, OrbitRadius, FlightSpeed and SpawnDistance control flight.
DefenderSeconds and SmokeSeconds apply when the relevant mission stage starts.
CooldownDays is clamped to a minimum of two. GripX/Y/Z and GripPitch/Yaw/Roll
adjust the held flare live; offsets are local meters and rotations are degrees.



LORE
Home Guard is a scattered crew keeping a few old rotors flying over Navezgane.
Their favor signal promises one friend overhead, not a rescue ride.
Friends don't let friends die alone. No refunds after the rotors start.

0.1.1 CHANGES
Completion-time bonus grants replace start-time reward-list injection.
Friendly defender bypasses the APH patrol resolver; normal patrol resolution remains native.
Signal calls are blocked if the supported APH isolation hooks cannot install.
Display title changed to A Call From Home; internal mod/item/quest IDs are preserved.

