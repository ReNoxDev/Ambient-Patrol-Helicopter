AMBIENT PATROL HELICOPTER 0.2.7 - 7D2D 3.1

	You dont have to fight the helicopter if you do not want to, by default it is passive until you shoot at it, it wont hit you until after you hit it!!
	If you dont fight it youll get a normal airdrop with a % chance to drop on despawn, If you do fight and kill it you get a buffed Lootdrop.
	
	
<-- COMBAT -->
Normal patrols keep their existing behavior. Player damage starts retaliation.
2000 HP maximum; normal weapon hits use a tagged vehicle collider.
1000 HP or less: main rotor smoke.
500 HP or less: main and tail rotor smoke/fire.
250 HP or less: up to two rockets per attack run; rearm while circling.

The helicopter circles for 12 seconds, then makes an 11-second overpass.
Bullets fire every 0.15 seconds during the opening 8 seconds of the run.
Each bullet has a 10% hit roll and requires clear line of sight. Hits apply
15 BASE damage through the game's normal damage/armor handling.
Rockets travel at 42 m/s, use swept collision checks, and cause native game
explosions: 60 base damage, 4 m entity radius, no block damage by default.
The existing smoothly aimed searchlight and audio sequence are retained.
Combat state and shot/rocket visuals are sent from the server to clients.

At zero HP the aircraft falls, explodes on ground/structure impact, stops its
audio, and releases one salvage airdrop with six nearby zombie guards.
Crash explosion: 80 base entity damage within 7 m; no block damage.
Salvage is generated once, at the last attacker's loot stage +50, using vanilla
airdrop, scaled weapons/armor/mods and ammunition groups. A separate 15% roll
adds 1-2 legendary parts. This boosts the loot distribution; it does not promise
that every item is a high-tier weapon. The crate uses the native supply-crate
entity, with prefilled contents and a saved custom-variable marker for its
special loot table/name.

If the target dies or disconnects, the helicopter circles their last position.
After five quiet real-time minutes from that transition it heals to 2000 and
resumes normal patrol. New incoming damage provokes the new attacker.
The normal event timeout is suspended during combat and restarts on recovery.
An ongoing fight is not saved across a server/game restart; this remains a
transient patrol event. Spawned salvage uses the native crate save behavior.



Test Commands F1 console

DM (DebugMenu On)
 ph start  (Starts Event)
 ph stop   (Stops Event)
 ph status (Tells you if event is active)
 phcombat status (Tells you if it is fighting)
 phcombat damage (Shows you total HP on Helicopter)
 ph combat probe  (Probe reports distance, combat attachment, hitbox size, aim intersection and
last native firearm range.)



This is area patrol, not obstacle-aware flight AI. For added Ambience to the world Patrol Helicopter spawns in searches for nearest player, 
It then flys around player, around pois, and around infected. It shoots and kills zombies but never hits the player.
30% chance it spawns an airdrop for supplies for players when it goes to despawn. Audio cue for Spawning in switches to ambience audio then plays a warning message every 2mins.



EAC must be disabled. Configuration: PatrolSettings.txt.

<-- Patrol Settings .txt -->

# Ambient Patrol Helicopter settings
EventsPerDay=2 (More events up to 24, each event is based on in game time cycle 24 hours so 2 per day means 2 hours within that day it can spawn)
DurationSeconds=420 (Time in seconds for how long Patrol Heli is active before despawning)
Height=70 (Height from players)
OrbitRadius=145 (Distance from player)
ZombieDamage=35 (Dmg done to zombies)
ZombieTargetChance=0.72 (Precentage chance to target zombies 1.00 being 100%)
AirdropChance=0.30 (Precentage if air drop chance after despawn)
WarningBurstSound=Weapons/Ranged/M60/m60_fire (Dont touch, this is just for audio cues for shooting)

# Days between scheduled event days. 1 = daily; 3 = days 1, 4, 7, 10, etc.
# EventsPerDay still controls the number of events on each eligible day.
DaysBetweenEvents=1 (0 Disables it if you want to manually spawn the event yourself)

# True permits one boosted event on a blood moon day, even between normal event days.
# Boost: +10 gamestage, increased HP, +10 lootstage 
# False uses the normal schedule and no boost. Blood moon days still allow at most one event.
# EventsPerDay=0 disables all scheduled events. Rockets remain gated at 12.5% HP.
BoostOnBloodMoon=True (False disables it)


You can replace the audio files in Resources/PatrolAudio by swaping the names from the files to the new sound .Wav files you wanna use, MP3 also works.

Ambience (is the constant playing sound where helicopter is flying)
Fly Over ( Is the original sound it pays when spawning in)
Survivor Search Radious (is the message it plays avery 2mins starting at the 30 second mark from when it spawns in)




<-- Combat Settings . txt -->

CircleSeconds=12  (Time in seconds Helicopter will circle before returning to engagement)
RocketDamage=60   (Dmg rockets will do to player if hit)
Guards=6          (Amount of zombies that will spawn to deffend the Airdrop)
LootStageBonus=50  (Loot Stage Bonus to apply to the loot drops above player current teir)
RarePartsChance=0.15 (Chance for Rare parts to drop)


\\Credits//
Flanua: For idea
Manux: for manux_HelicopterOH58.unity3d asset.
Bdubyah: for UI atlas icon.


Install on all clients and the host/server, replacing the existing folder.
Multiplayer Ready ✔
Solo Play Ready ✔